﻿using System;

namespace RockPaperScissors.SpanishApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola!");
        }
    }
}
