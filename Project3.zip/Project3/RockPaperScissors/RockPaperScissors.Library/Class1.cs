﻿using System;

namespace RockPaperScissors.Library
{
    public class Class1
    {
    }
}
