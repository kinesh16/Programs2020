﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RockPaperScissors.Library
{
    public class SomeOtherStrategy : IRpsStrategy
    {
        public string DecideMove(List<string> previousOutcomes)
        {
            throw new NotImplementedException();
        }
    }
}
